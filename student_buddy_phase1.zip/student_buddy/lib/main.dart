import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'app.dart';
import 'core/config/app_config.dart';
import 'core/state/settings_controller.dart';
import 'core/theme/app_theme.dart';
import 'core/widgets/logo.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1. Configuration must have been supplied at build time.
  final problems = AppConfig.problems;
  if (problems.isNotEmpty) {
    runApp(_ConfigErrorApp(problems: problems, rebuildNeeded: true));
    return;
  }

  // 2. Initialise Supabase; show a clear screen instead of crashing on failure.
  try {
    await Supabase.initialize(
      url: AppConfig.supabaseUrl,
      anonKey: AppConfig.supabaseAnonKey,
    );
  } catch (e) {
    runApp(_ConfigErrorApp(
      problems: const [
        'Supabase could not start with the supplied URL / key. '
            'Check both values for typos.'
      ],
      rebuildNeeded: true,
      details: e.toString(),
    ));
    return;
  }

  final prefs = await SharedPreferences.getInstance();
  runApp(ProviderScope(
    overrides: [sharedPrefsProvider.overrideWithValue(prefs)],
    child: const StudentBuddyApp(),
  ));
}

/// Shown instead of a half-working app when the build has no valid configuration.
class _ConfigErrorApp extends StatelessWidget {
  const _ConfigErrorApp({
    required this.problems,
    required this.rebuildNeeded,
    this.details,
  });
  final List<String> problems;
  final bool rebuildNeeded;
  final String? details;

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light(),
        home: Scaffold(
          body: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const LogoMark(size: 88),
                    const SizedBox(height: 24),
                    const Text('Student Buddy is not configured',
                        style: TextStyle(
                            fontSize: 22, fontWeight: FontWeight.w700),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    for (final p in problems)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Text('• $p', textAlign: TextAlign.center),
                      ),
                    const SizedBox(height: 12),
                    if (rebuildNeeded)
                      const Text(
                        'These values are compiled into the app, so the app must '
                        'be rebuilt after fixing them.\n\n'
                        'GitHub: add repository secrets SUPABASE_URL and '
                        'SUPABASE_ANON_KEY, then re-run the workflow.\n'
                        'Local: flutter run --dart-define-from-file=env.json',
                        textAlign: TextAlign.center,
                      ),
                    if (details != null) ...[
                      const SizedBox(height: 12),
                      Text(details!,
                          style: const TextStyle(fontSize: 11),
                          textAlign: TextAlign.center),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}
