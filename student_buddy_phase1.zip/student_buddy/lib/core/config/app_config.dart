/// Build-time configuration, injected with --dart-define / --dart-define-from-file.
///
/// Only PUBLIC values belong here: the Supabase project URL and the anon
/// (or publishable) key. They are protected by Row Level Security, not by secrecy.
/// NEVER put the Supabase service_role / secret key or the AI key in the app.
class AppConfig {
  static const _rawUrl = String.fromEnvironment('SUPABASE_URL');
  static const _rawKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  /// Trimmed, without trailing slashes (copy-paste often adds whitespace).
  static String get supabaseUrl =>
      _rawUrl.trim().replaceAll(RegExp(r'/+$'), '');
  static String get supabaseAnonKey => _rawKey.trim();

  /// Human-readable list of what is wrong. Empty = configuration is usable.
  static List<String> get problems => validate(supabaseUrl, supabaseAnonKey);
  static bool get isConfigured => problems.isEmpty;

  /// Pure function so it can be unit-tested. Never includes the values themselves.
  static List<String> validate(String url, String key) {
    final out = <String>[];
    if (url.isEmpty) {
      out.add('SUPABASE_URL is missing (empty at build time).');
    } else {
      final uri = Uri.tryParse(url);
      if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
        out.add('SUPABASE_URL must start with https:// '
            '(example: https://abcdxyz.supabase.co).');
      } else if (uri.path.isNotEmpty && uri.path != '/') {
        out.add('SUPABASE_URL must be only the project URL, '
            'without a path such as /rest/v1.');
      }
    }
    if (key.isEmpty) {
      out.add('SUPABASE_ANON_KEY is missing (empty at build time).');
    } else if (key.startsWith('sb_secret_')) {
      out.add('SUPABASE_ANON_KEY is a SECRET key. Use the anon / publishable '
          'key instead. Never ship a secret key in an app.');
    }
    return out;
  }

  static const appName = 'Student Buddy';
  static const version = '0.1.0';
}
