import 'package:flutter_test/flutter_test.dart';
import 'package:student_buddy/core/config/app_config.dart';

void main() {
  const goodUrl = 'https://abcdxyz.supabase.co';

  test('valid config has no problems', () {
    expect(AppConfig.validate(goodUrl, 'eyJhbGciOi.payload.sig'), isEmpty);
    expect(AppConfig.validate(goodUrl, 'sb_publishable_abc'), isEmpty);
  });

  test('missing values are reported', () {
    final p = AppConfig.validate('', '');
    expect(p.length, 2);
    expect(p.first, contains('SUPABASE_URL'));
    expect(p.last, contains('SUPABASE_ANON_KEY'));
  });

  test('bad URL shapes are reported', () {
    expect(AppConfig.validate('abcdxyz.supabase.co', 'k'), isNotEmpty);
    expect(AppConfig.validate('http://abcdxyz.supabase.co', 'k'), isNotEmpty);
    expect(AppConfig.validate('$goodUrl/rest/v1', 'k'), isNotEmpty);
  });

  test('secret keys are rejected', () {
    expect(AppConfig.validate(goodUrl, 'sb_secret_abc'), isNotEmpty);
  });

  test('problem messages never contain the supplied values', () {
    final p = AppConfig.validate('http://leak.example', 'sb_secret_TOPSECRET');
    expect(p.join(' '), isNot(contains('TOPSECRET')));
    expect(p.join(' '), isNot(contains('leak.example')));
  });
}
