import 'package:shared_preferences/shared_preferences.dart';

/// Small offline cache (Phase 1: the signed-in user's profile).
///
/// Uses shared_preferences, so it needs no native SQLite libraries and no code
/// generation. Larger offline data (notes, flashcards, saved answers) will get a
/// proper database in the phase that needs it.
class LocalCache {
  LocalCache(this._prefs);
  final SharedPreferences _prefs;

  static const _profilePrefix = 'profile_cache_';

  Future<void> saveProfile(String userId, String json) async {
    await _prefs.setString('$_profilePrefix$userId', json);
  }

  Future<String?> loadProfile(String userId) async =>
      _prefs.getString('$_profilePrefix$userId');

  /// Wipes all cached user data (called on sign-out / account deletion).
  Future<void> clearAll() async {
    for (final key in _prefs.getKeys().toList()) {
      if (key.startsWith(_profilePrefix)) {
        await _prefs.remove(key);
      }
    }
  }
}
