// Student Buddy - secure AI proxy.
// The AI provider key lives ONLY in Supabase secrets, never in the app.
//
// Secrets: AI_PROVIDER (anthropic | openai | openai_compatible), AI_API_KEY, AI_MODEL,
//          AI_BASE_URL (optional, openai_compatible only),
//          DAILY_FREE_LIMIT (default 30), DAILY_PREMIUM_LIMIT (default 300)
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

class HttpError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
  }
}

type Msg = { role: "user" | "assistant"; content: string };
const TIMEOUT_MS = 30_000;
const MAX_INPUT_CHARS = 20_000;

async function callProvider(system: string | undefined, messages: Msg[], maxTokens: number) {
  const provider = (Deno.env.get("AI_PROVIDER") ?? "anthropic").toLowerCase();
  const key = Deno.env.get("AI_API_KEY");
  const model = Deno.env.get("AI_MODEL");
  if (!key || !model) {
    throw new HttpError(503, "ai_not_configured",
      "AI is not configured yet. The administrator must set AI_API_KEY and AI_MODEL.");
  }

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    let res: Response;
    if (provider === "anthropic") {
      res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        signal: ctrl.signal,
        headers: {
          "content-type": "application/json",
          "x-api-key": key,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({ model, max_tokens: maxTokens, system, messages }),
      });
    } else {
      const base = (Deno.env.get("AI_BASE_URL") ?? "https://api.openai.com/v1").replace(/\/$/, "");
      const msgs = system ? [{ role: "system", content: system }, ...messages] : messages;
      res = await fetch(`${base}/chat/completions`, {
        method: "POST",
        signal: ctrl.signal,
        headers: { "content-type": "application/json", authorization: `Bearer ${key}` },
        body: JSON.stringify({ model, max_tokens: maxTokens, messages: msgs }),
      });
    }

    if (res.status === 429) {
      throw new HttpError(429, "provider_rate_limited", "The AI is busy right now. Please try again in a minute.");
    }
    if (!res.ok) {
      console.error("Provider error", res.status, await res.text());
      throw new HttpError(502, "provider_error", "The AI service returned an error. Please try again later.");
    }
    const data = await res.json();
    const text = provider === "anthropic"
      ? (data.content ?? []).filter((b: { type: string }) => b.type === "text")
          .map((b: { text: string }) => b.text).join("")
      : data.choices?.[0]?.message?.content ?? "";
    return { text: text as string, provider, model };
  } catch (e) {
    if (e instanceof HttpError) throw e;
    if (e instanceof DOMException && e.name === "AbortError") {
      throw new HttpError(504, "timeout", "The AI took too long to respond. Please try again.");
    }
    console.error("Provider fetch failed", e);
    throw new HttpError(502, "provider_unreachable", "Could not reach the AI service.");
  } finally {
    clearTimeout(timer);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed", message: "Use POST." }, 405);

  try {
    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // 1. Authenticate the caller
    const token = (req.headers.get("Authorization") ?? "").replace("Bearer ", "");
    const { data: userData, error: authError } = await admin.auth.getUser(token);
    if (authError || !userData.user) throw new HttpError(401, "unauthorized", "Please sign in to use AI.");
    const userId = userData.user.id;

    // 2. Validate input
    const body = await req.json().catch(() => ({}));
    const action = body.action ?? "chat";

    if (action === "ping") {
      const r = await callProvider(undefined, [{ role: "user", content: "Reply with the word OK." }], 10);
      return json({ ok: true, provider: r.provider, model: r.model });
    }
    if (action !== "chat") throw new HttpError(400, "bad_request", "Unknown action.");

    const messages: Msg[] = Array.isArray(body.messages) ? body.messages : [];
    const valid = messages.length > 0 && messages.every((m) =>
      (m?.role === "user" || m?.role === "assistant") && typeof m.content === "string" && m.content.trim() !== "");
    const size = messages.reduce((n, m) => n + (m.content?.length ?? 0), 0) + (body.system?.length ?? 0);
    if (!valid || size > MAX_INPUT_CHARS) {
      throw new HttpError(400, "bad_request", "Invalid or too-long request.");
    }

    // 3. Enforce the daily limit
    const { data: profile } = await admin.from("profiles").select("plan").eq("id", userId).maybeSingle();
    const limit = profile?.plan === "premium"
      ? Number(Deno.env.get("DAILY_PREMIUM_LIMIT") ?? 300)
      : Number(Deno.env.get("DAILY_FREE_LIMIT") ?? 30);
    const dayStart = new Date(); dayStart.setUTCHours(0, 0, 0, 0);
    const { count } = await admin.from("ai_usage").select("id", { count: "exact", head: true })
      .eq("user_id", userId).gte("created_at", dayStart.toISOString());
    if ((count ?? 0) >= limit) {
      throw new HttpError(429, "daily_limit", "You have reached today's AI limit. Please come back tomorrow.");
    }

    // 4. Call the AI, then record usage
    const maxTokens = Math.min(Number(body.max_tokens ?? 1500), 4000);
    const r = await callProvider(body.system, messages, maxTokens);
    await admin.from("ai_usage").insert({ user_id: userId, feature: body.feature ?? "chat" });
    return json({ text: r.text });
  } catch (e) {
    if (e instanceof HttpError) return json({ error: e.code, message: e.message }, e.status);
    console.error("Unhandled", e);
    return json({ error: "internal", message: "Something went wrong on the server." }, 500);
  }
});
