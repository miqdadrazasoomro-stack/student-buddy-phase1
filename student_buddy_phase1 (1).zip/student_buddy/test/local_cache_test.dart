import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:student_buddy/core/database/local_cache.dart';

void main() {
  test('LocalCache saves, loads and clears profiles', () async {
    SharedPreferences.setMockInitialValues({'theme': 'dark'});
    final cache = LocalCache(await SharedPreferences.getInstance());

    expect(await cache.loadProfile('u1'), isNull);
    await cache.saveProfile('u1', '{"id":"u1"}');
    expect(await cache.loadProfile('u1'), '{"id":"u1"}');

    await cache.clearAll();
    expect(await cache.loadProfile('u1'), isNull);
    // unrelated settings are untouched
    expect((await SharedPreferences.getInstance()).getString('theme'), 'dark');
  });
}
